public class HelloWorld : IHelloWorld
{
    public string SayIt(string name)
    {
        return "";
    }
}