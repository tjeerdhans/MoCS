public interface IHelloWorld
{
    string SayIt(string name);
}